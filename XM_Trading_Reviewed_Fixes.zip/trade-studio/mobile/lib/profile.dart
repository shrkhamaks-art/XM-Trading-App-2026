import 'package:flutter/material.dart';

import 'api.dart';

class CustomerProfileScreen extends StatefulWidget {
  const CustomerProfileScreen({
    super.key,
    required this.api,
    required this.english,
  });

  final StudioApi api;
  final bool english;

  @override
  State<CustomerProfileScreen> createState() => _CustomerProfileScreenState();
}

class _CustomerProfileScreenState extends State<CustomerProfileScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _smsCode = TextEditingController();
  String? _savedPhone;
  bool _phoneVerified = false;
  bool _smsSent = false;
  Map<String, dynamic> _documents = {};
  final _accepted = <String>{};
  bool _busy = false;
  String? _message;

  String t(String ar, String en) => widget.english ? en : ar;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _smsCode.dispose();
    super.dispose();
  }

  Future<void> _perform(Future<void> Function() action) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = null;
    });
    try {
      await action();
    } on ApiFailure catch (error) {
      if (mounted) {
        setState(
          () => _message = t(
            error.message,
            'The request could not be completed.',
          ),
        );
      }
    } on Exception {
      if (mounted) {
        setState(
          () => _message = t(
            'تعذّر الاتصال بالخادم.',
            'Could not reach the server.',
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _load() => _perform(() async {
    final profile =
        (await widget.api.request('profile'))['profile']
            as Map<String, dynamic>?;
    final result = await widget.api.request('onboarding/documents');
    if (!mounted) return;
    setState(() {
      _name.text = profile?['full_name'] as String? ?? '';
      _savedPhone = profile?['phone'] as String?;
      _phone.text = _savedPhone ?? '';
      _phoneVerified = profile?['phone_verified'] == true;
      _documents = result['documents'] as Map<String, dynamic>;
      _accepted.clear();
    });
  });

  Future<void> _save() => _perform(() async {
    final result = await widget.api.request('profile', {
      'full_name': _name.text,
      'phone': _phone.text,
      'accepted': true,
      'versions': {
        for (final item in _documents.entries)
          item.key: (item.value as Map<String, dynamic>)['version'],
      },
    });
    if (mounted) {
      final profile = result['profile'] as Map<String, dynamic>;
      setState(() {
        final savedPhone = profile['phone'] as String;
        if (_savedPhone != savedPhone) {
          _smsSent = false;
          _smsCode.clear();
        }
        _savedPhone = savedPhone;
        _phoneVerified = profile['phone_verified'] == true;
        _message = t('حُفظ الملف.', 'Profile saved.');
      });
    }
  });

  Future<void> _requestSms() => _perform(() async {
    final result = await widget.api.request('phone/code', {});
    if (mounted) {
      setState(() {
        _phoneVerified = result['status'] == 'already_verified';
        _smsSent = !_phoneVerified;
        _smsCode.clear();
        _message = _phoneVerified
            ? null
            : t('راجع رسائل الجوال.', 'Check your text messages.');
      });
    }
  });

  Future<void> _verifySms() => _perform(() async {
    final result = await widget.api.request('phone/verify', {
      'code': _smsCode.text.trim(),
    });
    if (mounted) {
      setState(() {
        _phoneVerified = result['phone_verified'] == true;
        _smsSent = false;
        _smsCode.clear();
      });
    }
  });

  String _title(String key) => switch (key) {
    'terms' => t('الشروط', 'Terms'),
    'privacy' => t('سياسة الخصوصية', 'Privacy policy'),
    _ => t('الإفصاح عن المخاطر', 'Risk disclosure'),
  };

  Future<void> _readDocument(String key) async {
    final document = _documents[key] as Map<String, dynamic>;
    final body = document['body'] as Map<String, dynamic>;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => Directionality(
        textDirection: widget.english ? TextDirection.ltr : TextDirection.rtl,
        child: AlertDialog(
          title: Text('${_title(key)} · ${document['version']}'),
          content: SingleChildScrollView(
            child: Text(body[widget.english ? 'en' : 'ar'] as String),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(t('إغلاق', 'Close')),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(t('أوافق', 'I accept')),
            ),
          ],
        ),
      ),
    );
    if (mounted && accepted == true) setState(() => _accepted.add(key));
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: widget.english ? TextDirection.ltr : TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(t('ملف العميل', 'Customer profile'))),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextField(
            controller: _name,
            enabled: !_busy,
            textCapitalization: TextCapitalization.words,
            maxLength: 120,
            decoration: InputDecoration(
              labelText: t('الاسم الرباعي', 'Full legal name'),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _phone,
            onChanged: (_) => setState(() {}),
            enabled: !_busy,
            keyboardType: TextInputType.phone,
            textDirection: TextDirection.ltr,
            maxLength: 16,
            decoration: InputDecoration(
              labelText: t(
                'الجوال بالصيغة الدولية',
                'International phone number',
              ),
            ),
          ),
          for (final key in _documents.keys)
            ListTile(
              leading: Icon(
                _accepted.contains(key)
                    ? Icons.check_circle_outline
                    : Icons.description_outlined,
              ),
              title: Text(_title(key)),
              onTap: _busy ? null : () => _readDocument(key),
            ),
          if (_savedPhone != null && _phone.text.trim() == _savedPhone) ...[
            if (_phoneVerified)
              Text(t('رقم الجوال موثّق.', 'Phone number verified.'))
            else ...[
              OutlinedButton(
                onPressed: _busy ? null : _requestSms,
                child: Text(
                  _smsSent
                      ? t('إعادة إرسال رمز الجوال', 'Resend phone code')
                      : t('إرسال رمز الجوال', 'Send phone code'),
                ),
              ),
              if (_smsSent) ...[
                TextField(
                  controller: _smsCode,
                  enabled: !_busy,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  decoration: InputDecoration(
                    labelText: t('رمز الجوال', 'Phone code'),
                  ),
                ),
                FilledButton(
                  onPressed: _busy ? null : _verifySms,
                  child: Text(t('تحقق من الرقم', 'Verify phone')),
                ),
              ],
            ],
          ],
          if (_busy) const LinearProgressIndicator(),
          if (_message case final message?) Text(message),
          if (_documents.isEmpty)
            TextButton(
              onPressed: _busy ? null : _load,
              child: Text(t('إعادة المحاولة', 'Retry')),
            ),
          FilledButton(
            onPressed: !_busy && _documents.length == 3 && _accepted.length == 3
                ? _save
                : null,
            child: Text(t('حفظ الملف', 'Save profile')),
          ),
        ],
      ),
    ),
  );
}
