import json
import os
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from wsgiref.simple_server import WSGIRequestHandler, make_server

from backend.server import create_app


class QuietHandler(WSGIRequestHandler):
    def log_message(self, *args):
        pass


class OnboardingTests(unittest.TestCase):
    def setUp(self):
        work = tempfile.TemporaryDirectory()
        self.addCleanup(work.cleanup)
        self.path = Path(work.name) / "accounts.sqlite"
        self.codes = {}
        self.sms = []
        self.versions = {"terms": "terms-1", "privacy": "privacy-2", "risk": "risk-1"}
        path = Path(work.name) / "documents.json"
        path.write_text(json.dumps({
            key: {"version": version, "body": {"ar": "نص اختبار", "en": "Test fixture"}}
            for key, version in self.versions.items()
        }))
        with patch.dict(os.environ, {"ONBOARDING_DOCUMENTS_FILE": str(path)}):
            app = create_app(self.path, b"x" * 32, self.codes.__setitem__,
                             send_sms=lambda phone, code: self.sms.append((phone, code)))
        server = make_server("127.0.0.1", 0, app, handler_class=QuietHandler)
        self.addCleanup(server.server_close)
        thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02})
        thread.start()
        self.addCleanup(thread.join)
        self.addCleanup(server.shutdown)
        self.origin = f"http://127.0.0.1:{server.server_port}"

    def request(self, path, data=None, cookie=""):
        payload = None if data is None else json.dumps(data).encode()
        req = Request(self.origin + path, payload, {
            "Content-Type": "application/json", "Cookie": cookie,
        })
        try:
            response = urlopen(req, timeout=5)
        except HTTPError as error:
            response = error
        with response:
            return response.status, json.load(response), response.headers

    def login(self, email):
        self.assertEqual(self.request("/api/code", {"email": email})[0], 200)
        status, _, headers = self.request("/api/verify", {
            "email": email, "code": self.codes[email],
        })
        self.assertEqual(status, 200)
        return headers["Set-Cookie"].split(";", 1)[0]

    def profile(self, **overrides):
        return {
            "full_name": "سالم أحمد علي حسن", "phone": "+967712345678",
            "accepted": True, "versions": self.versions, **overrides,
        }

    def test_save_read_update_and_account_isolation(self):
        self.assertEqual(self.request("/api/profile")[0], 401)
        self.assertEqual(self.request("/api/profile", self.profile())[0], 401)
        cookie = self.login("owner@example.org")
        other = self.login("other@example.org")
        self.assertEqual(self.request("/api/profile", cookie=cookie)[1], {"profile": None})
        docs = self.request("/api/onboarding/documents")[1]["documents"]
        self.assertEqual({key: value["version"] for key, value in docs.items()}, self.versions)
        result = self.request("/api/profile", self.profile(email="other@example.org"), cookie)
        self.assertEqual(result[0], 200)
        self.assertFalse(result[1]["profile"]["phone_verified"])
        self.assertEqual(self.request("/api/profile", cookie=cookie)[1], result[1])
        self.assertEqual(self.request("/api/profile", cookie=other)[1], {"profile": None})
        self.assertEqual(self.request("/api/profile", self.profile(phone="+967711111111"), cookie)[0], 200)
        with sqlite3.connect(self.path) as db:
            rows = db.execute("SELECT email, document, version, accepted FROM customer_consents").fetchall()
        self.assertEqual(len(rows), 3)
        self.assertTrue(all(email == "owner@example.org" and accepted > 0 for email, _, _, accepted in rows))
        self.assertEqual({document: version for _, document, version, _ in rows}, self.versions)

    def test_invalid_inputs_and_stale_versions_do_not_create_profile(self):
        cookie = self.login("owner@example.org")
        for overrides, status in (
            ({"accepted": False}, 409),
            ({"versions": {**self.versions, "terms": "old"}}, 409),
            ({"full_name": "اسم واحد"}, 400),
            ({"phone": "712345678"}, 400),
        ):
            with self.subTest(overrides=overrides):
                self.assertEqual(self.request("/api/profile", self.profile(**overrides), cookie)[0], status)
        self.assertEqual(self.request("/api/profile", cookie=cookie)[1], {"profile": None})

    def test_phone_code_lifecycle_and_number_change(self):
        self.assertEqual(self.request("/api/phone/code", {})[0], 401)
        owner = self.login("owner@example.org")
        other = self.login("other@example.org")
        self.assertEqual(self.request("/api/phone/code", {}, owner)[0], 409)
        self.assertEqual(self.request("/api/profile", self.profile(), owner)[0], 200)
        status, response, _ = self.request("/api/phone/code", {}, owner)
        self.assertEqual((status, response), (200, {"status": "sent"}))
        phone, code = self.sms[-1]
        self.assertEqual(phone, self.profile()["phone"])
        self.assertEqual(self.request("/api/phone/code", {}, owner)[0], 429)
        self.assertEqual(self.request("/api/phone/verify", {"code": code}, other)[0], 401)
        wrong = "000000" if code != "000000" else "111111"
        self.assertEqual(self.request("/api/phone/verify", {"code": wrong}, owner)[0], 401)
        self.assertEqual(self.request("/api/phone/verify", {"code": code}, owner)[1],
                         {"phone_verified": True})
        self.assertEqual(self.request("/api/phone/verify", {"code": code}, owner)[0], 401)
        self.assertTrue(self.request("/api/profile", cookie=owner)[1]["profile"]["phone_verified"])
        self.assertEqual(self.request("/api/phone/code", {}, owner)[1], {"status": "already_verified"})
        changed = self.request("/api/profile", self.profile(phone="+967711111111"), owner)
        self.assertFalse(changed[1]["profile"]["phone_verified"])
        restored = self.request("/api/profile", self.profile(), owner)
        self.assertFalse(restored[1]["profile"]["phone_verified"])

    def test_expired_or_changed_phone_codes_are_rejected(self):
        with patch("backend.server.time.time", return_value=1000):
            owner = self.login("owner@example.org")
            self.assertEqual(self.request("/api/profile", self.profile(), owner)[0], 200)
            self.assertEqual(self.request("/api/phone/code", {}, owner)[0], 200)
        code = self.sms[-1][1]
        with patch("backend.server.time.time", return_value=1300):
            self.assertEqual(self.request("/api/phone/verify", {"code": code}, owner)[0], 401)
            self.assertEqual(self.request("/api/phone/code", {}, owner)[0], 200)
            self.assertEqual(self.request("/api/profile", self.profile(phone="+967711111111"), owner)[0], 200)
            self.assertEqual(self.request("/api/phone/verify", {"code": self.sms[-1][1]}, owner)[0], 401)
