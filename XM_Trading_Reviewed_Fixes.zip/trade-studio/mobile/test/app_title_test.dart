import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:trade_studio/main.dart';

void main() {
  testWidgets('app and visible header use XM', (tester) async {
    await tester.pumpWidget(const TradeStudio());
    expect(find.text('XM'), findsOneWidget);
    final app = tester.widget<MaterialApp>(find.byType(MaterialApp));
    expect(app.title, 'XM');
  });
}
