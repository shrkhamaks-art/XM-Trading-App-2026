# ملاحظات الحزمة المعدلة

- تم تعديل عنوان Flutter الظاهر إلى XM.
- تم ضبط تسمية AndroidManifest الذي يولده Flutter إلى XM وإضافة إذن الإنترنت إذا لم يوجد.
- أضيف تحقق من رابط API الآمن قبل البناء.
- أضيف تحقق من وجود أدوات Android SDK المطلوبة.
- أزيل خيار إعداد Android SDK غير الضروري الذي قد يسبب اختلافًا في التنفيذ.
- لم يُشغّل GitHub Actions أو Flutter فعليًا هنا؛ لا يوجد APK داخل الحزمة.
- مسارا Android وFlutter منفصلان؛ اختر مسار Flutter لتطبيق الواجهة متعددة المنصات.
- استخدام XM وشعارها تجاريًا يتطلب تصريحًا من صاحب العلامة؛ هذه التعديلات لا تثبت وجوده.

## خطوات البناء
1. ارفع المشروع إلى مستودع GitHub على فرع منفصل.
2. افتح Actions ثم Trade Studio Flutter builds ثم Run workflow.
3. أدخل عنوان خادم HTTPS منشور فعليًا في api_origin.
4. تحقق من نجاح flutter analyze وflutter test وبناء APK.
5. نزّل artifact المسمى trade-studio-android-test وافحص التطبيق على جهاز حقيقي.
